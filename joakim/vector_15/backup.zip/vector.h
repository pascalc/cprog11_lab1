#ifndef VECTOR_15_H
#define VECTOR_15_H

#include <stdlib.h>

template<class T>
class Vector {
	public:
		typedef T *iterator;
		// Constructors
		Vector();
		explicit Vector(size_t size);
		Vector(size_t size, const T &val);
		Vector(const Vector<T> &v);
		// Deconstructor
		~Vector();

		// Functions
		const T operator[](size_t i) const;
		T& operator[](size_t i);
		Vector& operator=(const Vector<T> &vector);
		void push_back(const T &elem);	// Add element elem last in the vector
		void insert(size_t i, const T &elem);	// Insert element elem before index i	
		void erase(size_t i);	// Erase element at index i 
		void clear();	// Remove ALL elements in the vector
		// Should be const!
		unsigned size() const;	// Return number of elements in the vector.
		void sort(bool ascending); // Sort in asc/desc order. Default is asc
		void resize();	// Change capacity to meet requirments
		
	private:
		// Variables
		unsigned int capacity;		// capacity of the vector
		unsigned int my_size;		// size of the vector
		T* array;					// underlaying array of type T (generic)
};
#endif